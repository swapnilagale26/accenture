// JavaScript Document
courseMap="<courseMap>";
courseMap=courseMap+"<course title='Time Management'>";

//Lesson 1
courseMap=courseMap+"<lesson01 title='Welcome!'>";
courseMap=courseMap+"<page title='Welcome!'>html/TM_01_01.html</page>";
courseMap=courseMap+"<page title='Managing Your Time'>html/TM_01_02.html</page>";
courseMap=courseMap+"</lesson01>";
//:::::::::::::::::::::::::::::::::

//Lesson 2
courseMap=courseMap+"<lesson02 title='Prioritising Your Tasks'>";
courseMap=courseMap+"<page title='Prioritising Your Work Tasks'>html/TM_01_03.html</page>";
courseMap=courseMap+"<page title='Factors to Consider'>html/TM_01_04.html</page>";
courseMap=courseMap+"</lesson02>";
//:::::::::::::::::::::::::::::::::

//Lesson 3
courseMap=courseMap+"<lesson03 title='Cutting Down on Time Wasters'>";
courseMap=courseMap+"<page title='Cutting Down on Time Wasters'>html/TM_01_05.html</page>";
courseMap=courseMap+"<page title='Conclusion'>html/TM_01_06.html</page>";
courseMap=courseMap+"</lesson03>";
//:::::::::::::::::::::::::::::::::

//Lesson 4
courseMap=courseMap+"<lesson04 title='Summary'>";
courseMap=courseMap+"<page title='Summary'>html/TM_01_07.html</page>";
courseMap=courseMap+"</lesson04>";
//:::::::::::::::::::::::::::::::::

//Lesson 5
courseMap=courseMap+"<lesson05 title='Assessment'>";
courseMap=courseMap+"<page title='Question 1'>html/TM_01_08.html</page>";
courseMap=courseMap+"<page title='Question 2'>html/TM_01_09.html</page>";
courseMap=courseMap+"<page title='Question 3'>html/TM_01_10.html</page>";
courseMap=courseMap+"<page title='Final Result'>html/TM_01_11.html</page>";
courseMap=courseMap+"</lesson05>";
//:::::::::::::::::::::::::::::::::

courseMap=courseMap+"</course>";
courseMap=courseMap+"</courseMap>";